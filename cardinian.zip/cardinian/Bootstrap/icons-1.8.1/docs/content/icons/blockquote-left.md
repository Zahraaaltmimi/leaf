---
title: Blockquote left
categories:
  - Typography
tags:
  - text
  - type
---
