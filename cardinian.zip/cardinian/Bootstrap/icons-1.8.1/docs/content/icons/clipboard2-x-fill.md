---
title: Clipboard2 x fill
categories:
  - Real world
tags:
  - copy
  - paste
---
